from django.urls import path
from .views import (
    AutorList, CrearAutor, 
    EditorialList, CrearEditorial,
    LibroList, CrearLibro, 
    MiembroList, CrearMiembro,  
    PrestamoList, CrearPrestamo
)

urlpatterns = [
    # URLs para Autor
    path('autores/', AutorList.as_view(), name='autor-list'),
    path('autores/crear/', CrearAutor.as_view(), name='crear-autor'),

    # URLs para Editorial
    path('editoriales/', EditorialList.as_view(), name='editorial-list'),
    path('editoriales/crear/', CrearEditorial.as_view(), name='crear-editorial'),

    # URLs para Libro
    path('libros/', LibroList.as_view(), name='libro-list'),
    path('libros/crear/', CrearLibro.as_view(), name='crear-libro'),

    # URLs para Miembro (antes Usuario)
    path('miembros/', MiembroList.as_view(), name='miembro-list'),
    path('miembros/crear/', CrearMiembro.as_view(), name='crear-miembro'),

    # URLs para Préstamo
    path('prestamos/', PrestamoList.as_view(), name='prestamo-list'),
    path('prestamos/crear/', CrearPrestamo.as_view(), name='crear-prestamo'),
]
