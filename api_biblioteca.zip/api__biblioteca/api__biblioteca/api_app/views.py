from django.shortcuts import render

# Create your views here.
from django.shortcuts import get_object_or_404
from rest_framework.response import Response
from rest_framework import generics, status
from rest_framework.exceptions import NotFound
from .models import Autor, Editorial, Libro, Miembro, Prestamo
from .serializers import AutorSerializer, EditorialSerializer, LibroSerializer, MiembroSerializer, PrestamoSerializer

# CRUD Autores 
class AutorList(generics.ListCreateAPIView):
    queryset = Autor.objects.all()
    serializer_class = AutorSerializer

    def get(self, request):
        autores = Autor.objects.all()
        serializer = AutorSerializer(autores, many=True)
        if not autores:
            raise NotFound('No se encontraron autores.')
        return Response({'success': True, 'detail': 'Listado de autores.', 'data': serializer.data}, status=status.HTTP_200_OK)

class CrearAutor(generics.CreateAPIView):
    queryset = Autor.objects.all()
    serializer_class = AutorSerializer

    def post(self, request):
        serializer = AutorSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response({'success': True, 'detail': 'Autor creado correctamente.', 'data': serializer.data}, status=status.HTTP_201_CREATED)

# CRUD Editoriales 
class EditorialList(generics.ListCreateAPIView):
    queryset = Editorial.objects.all()
    serializer_class = EditorialSerializer

    def get(self, request):
        editoriales = Editorial.objects.all()
        serializer = EditorialSerializer(editoriales, many=True)
        if not editoriales:
            raise NotFound('No se encontraron editoriales.')
        return Response({'success': True, 'detail': 'Listado de editoriales.', 'data': serializer.data}, status=status.HTTP_200_OK)

class CrearEditorial(generics.CreateAPIView):
    queryset = Editorial.objects.all()
    serializer_class = EditorialSerializer

    def post(self, request):
        serializer = EditorialSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response({'success': True, 'detail': 'Editorial creada correctamente.', 'data': serializer.data}, status=status.HTTP_201_CREATED)

# CRUD Libros 
class LibroList(generics.ListCreateAPIView):
    queryset = Libro.objects.all()
    serializer_class = LibroSerializer

    def get(self, request):
        libros = Libro.objects.all()
        serializer = LibroSerializer(libros, many=True)
        if not libros:
            raise NotFound('No se encontraron libros.')
        return Response({'success': True, 'detail': 'Listado de libros.', 'data': serializer.data}, status=status.HTTP_200_OK)

class CrearLibro(generics.CreateAPIView):
    queryset = Libro.objects.all()
    serializer_class = LibroSerializer

    def post(self, request):
        serializer = LibroSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response({'success': True, 'detail': 'Libro creado correctamente.', 'data': serializer.data}, status=status.HTTP_201_CREATED)

# CRUD Miembros 
class MiembroList(generics.ListCreateAPIView):
    queryset = Miembro.objects.all()
    serializer_class = MiembroSerializer

    def get(self, request):
        miembros = Miembro.objects.all()
        serializer = MiembroSerializer(miembros, many=True)
        if not miembros:
            raise NotFound('No se encontraron miembros.')
        return Response({'success': True, 'detail': 'Listado de miembros.', 'data': serializer.data}, status=status.HTTP_200_OK)

class CrearMiembro(generics.CreateAPIView):
    queryset = Miembro.objects.all()
    serializer_class = MiembroSerializer

    def post(self, request):
        serializer = MiembroSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response({'success': True, 'detail': 'Miembro creado correctamente.', 'data': serializer.data}, status=status.HTTP_201_CREATED)

# CRUD Préstamos
class PrestamoList(generics.ListCreateAPIView):
    queryset = Prestamo.objects.all()
    serializer_class = PrestamoSerializer

    def get(self, request):
        prestamos = Prestamo.objects.all()
        serializer = PrestamoSerializer(prestamos, many=True)
        if not prestamos:
            raise NotFound('No se encontraron préstamos.')
        return Response({'success': True, 'detail': 'Listado de préstamos.', 'data': serializer.data}, status=status.HTTP_200_OK)

class CrearPrestamo(generics.CreateAPIView):
    queryset = Prestamo.objects.all()
    serializer_class = PrestamoSerializer

    def post(self, request):
        serializer = PrestamoSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response({'success': True, 'detail': 'Préstamo registrado correctamente.', 'data': serializer.data}, status=status.HTTP_201_CREATED)
    
